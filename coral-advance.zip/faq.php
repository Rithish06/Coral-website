<?php include_once('./layout/header.php'); ?>
<div class="banner">
    <img src="/assets/images/water-molecules-with-copyspace-science-or-medical-2022-12-16-21-55-17-utc.png" />
   <div class="overlay">
       <div class="overlay-content h1 text-white text-bold">
          FAQ's
       </div>
   </div>
</div>

<div class="faq my-5">
    <div class="container">
        <div class="row">
            <div class="col-md-4 heading nav-tabs" id="nav-tabs" role="tablist">
                <h2>Services </h2>
                <div class="active"><a class="active" href="#1a" data-bs-toggle="tab" role="tab">Bladder & Pelvic Floor Health</a></div>
                <div><a href="#2a" data-bs-toggle="tab" role="tab">Male Fetility</a></div>
                <div><a href="#3a"  data-bs-toggle="tab" role="tab">Labor & Delivery</a></div>
                <div><a href="#4a"  data-bs-toggle="tab" role="tab">IVF</a></div>
            </div>
            <div class="col-md-8 content ">
                <div class="tab-content clearfix">
        			  <div class="tab-pane active mt-3" id="1a" role="tabpanel" >
                          <div class="col-md-12 my-3 py-4">
                               <span class="h5 number">01</span> &nbsp;&nbsp;
                               <span class="h5">What is Peliv Floor</span>
                               <br />
                               <br />
                               <p class="fs-5 mx-5">
                                  the Pelvic floor is group of muscles and tissues that form hammock-like structure at the bottom of the pelvis. It supports the pelvic organs, including the bladder, uterus, and rectum.
                               </p>
                          </div>
                          
                          <div class="col-md-12 my-3 py-4">
                              <span class="h5 number">02</span> &nbsp;&nbsp;
                               <span class="h5">
                                What is the role of the pelvic floor muscles?
                               </span>
                               <br />
                               <br />
                               <p class="fs-5 mx-5">
                                  the Pelvic floor is muscles play a crucial role in bladder and bowel control, as well as sexual function. hey help maintain continence, support the pelvic organs, and provide stability to the lower back tand pelvis.
                               </p>
                          </div>
                          
                          <div class="col-md-12 my-3 py-4">
                              <span class="h5 number">03</span> &nbsp;&nbsp;
                               <span class="h5">
                                What are common bladder problems in women?
                               </span>
                               <br />
                               <br />
                               <p class="fs-5 mx-5">
                                  Common bladder problems in women include urninary incotinence(leakage or urine), overactive bladder (frequently and urgent need to urinate), and urinary tract infections (UTIs).
                               </p>
                          </div>
                          
                          <div class="col-md-12 my-3 py-4">
                              <span class="h5 number">04</span> &nbsp;&nbsp;
                               <span class="h5">
                                What can I do maintin the helty bladder?
                               </span>
                                <br />
                               <br />
                               <p class="fs-5 mx-5">
                                    To Maintain a healthy bladder, you can: 
                               </p>
                               
                             
                               <ol class="fs-5  mx-5">
                                   <li class="pb-3">
                                       Stay hudrated but avoide excessive fluid intake before bedtime.
                                   </li>
                                   <li class="pb-3">
                                       Practive good toilet, suck as emptying your bladder completely andnot delatying urination. 
                                   </li>
                                   <li>
                                       Maintain a healty weight.
                                   </li>
                                   <li>
                                       Avoid or limit bladder irritants such as caffeine, alchohol, and spicy foods.
                                   </li>
                                   <li>
                                       Practice pelvic floor exercses to strengthen the muscles.
                                   </li>
                               </ul>
                          </div>
                          
                          <div class="col-md-12 my-3 py-4">
                              <span class="h5 number">05</span> &nbsp;&nbsp;
                               <span class="h5">
                                What are pelvic floor exercises and how do I do them?
                               </span>
                               <br />
                               <br />
                               <p class="fs-5 mx-5">
                                 Pelvic floor exercises, also known as kegel exercieses, involve contracting and relaxing the pelvic floor muscles. To perofm them, imagine stopping the flow of urine midsream. Squeez and lift the muscles in that area, hold for a few seconds and then relax. Repeat this serral times a day.
                               </p>
                          </div>
                          
                          <div class="col-md-12 my-3 py-4">
                              <span class="h5 number">06</span> &nbsp;&nbsp;
                               <span class="h5">
                                When should I see healthcare provider about bladder or pelvic floor issues?
                               </span>
                               <br />
                               <br />
                               <p class="fs-5 mx-5">
                                 You should consider seeing a healthcare provider if you experiences persistent symptoms such as urinary inconteinence, frequent unrination, pain during urination, plevic pain, or if your quality of life is affected by bladder or pelvic floor problems.
                               </p>
                          </div>
                          
                          
                	   </div>
                		<div class="tab-pane mt-3 " id="2a" role="tabpanel" >
                         <div class="col-md-12 my-3 py-4">
                              <span class="h5 number">01</span> &nbsp;&nbsp;
                               <span class="h5">
                                What is male fertility?
                               </span>
                               <br />
                               <br />
                               <p class="fs-5 mx-5">
                                 Male fertility refers to man's ability to impregnante a woman and father a child. It depends on the quantity, quality and motility(movment) of his sperm.
                               </p>
                          </div>
                          
                          <div class="col-md-12 my-3 py-4">
                              <span class="h5 number">02</span> &nbsp;&nbsp;
                               <span class="h5">
                                What factors can affect male fertility?
                               </span>
                               <br />
                               <br />
                               <p class="fs-5 mx-5">
                                 Several factors can imact male fertility, including age, health conditions (such as diabetes or infections), lifestyle choices(smoking, execessive alcohol consumtion, drug use), exposure to toxins, hormonal imbalances, obesity, certain medications, and genetic factors.
                               </p>
                          </div>
                          
                          <div class="col-md-12 my-3 py-4">
                              <span class="h5 number">03</span> &nbsp;&nbsp;
                               <span class="h5">
                                How common is male infertility?
                               </span>
                               <br />
                               <br />
                               <p class="fs-5 mx-5">
                                Male intertility is relatively common. About 15% of couples worlwide face difficulties conceiving, and in approxmately 40% of these case, male factors contirbutes in infertility.
                               </p>
                          </div>
                          
                          <div class="col-md-12 my-3 py-4">
                              <span class="h5 number">04</span> &nbsp;&nbsp;
                               <span class="h5">
                                Can lifestyle choices affect male fertility?
                               </span>
                               <br />
                               <br />
                               <p class="fs-5 mx-5">
                                Yes, certain lifestyle chouces can have significant impact on male fertility. Tobacco smoking, excessiove alchohol comsumtoion, drug use (including anabolic steoids), obesity, poor diet, sedentary lifestyle and prologes exposure to high temperatures ( such as hot tubs on saunas) can.
                               </p>
                          </div>
                          
                          <div class="col-md-12 my-3 py-4">
                              <span class="h5 number">05</span> &nbsp;&nbsp;
                               <span class="h5">
                                Can stress affect male fertility?
                               </span>
                               <br />
                               <br />
                               <p class="fs-5 mx-5">
                                Yes, chronic stress can potentially affect male fertility. Sress hormones, such as cortisol, may disrupt hormone levels and sperm production. It is is recommended to manage stress through relaxation techniques, exercies and seeking supprt when needed.
                               </p>
                          </div>
                          
                          <div class="col-md-12 my-3 py-4">
                              <span class="h5 number">06</span> &nbsp;&nbsp;
                               <span class="h5">
                                How does age aafect male fertility?
                               </span>
                               <br />
                               <br />
                               <p class="fs-5 mx-5">
                                While women have well-known decline in fertility with age, men also experience changes. As men get older, sperm count, sperm mortility and semen volume may decrease and the risk of fenetic abnormalities in sperm may increase. However, men can still father childres well into their later.
                               </p>
                          </div>
                          
                          <div class="col-md-12 my-3 py-4">
                              <span class="h5 number">07</span> &nbsp;&nbsp;
                               <span class="h5">
                                Can sexually transmitted infections (STIs) impact male fertility?
                               </span>
                               <br />
                               <br />
                               <p class="fs-5 mx-5">
                                Yes, certain SI can affect male fertility. Infections like chalamydia or gonorrrhea.If left untreated, can lead to conditions like epididymities or prostatitis, which may cause scarring and blockage in reprodcutive system, affecting sperm production and transport.
                               </p>
                          </div>
                          
                		</div>
                        
                        <div class="tab-pane" id="3a" role="tabpanel" >
                          <div class="col-md-12 my-3 py-4">
                              <span class="h5 number">01</span> &nbsp;&nbsp;
                               <span class="h5">
                                What is labor?
                               </span>
                               <br />
                               <br />
                               <p class="fs-5 mx-5">
                                Labor is the process by which a baby is born. It involves the rhythmic contractions of the uterus that help to dilate the cervix and push the baby through the birth canal.
                               </p>
                          </div>
                          
                          <div class="col-md-12 my-3 py-4">
                              <span class="h5 number">02</span> &nbsp;&nbsp;
                               <span class="h5">
                                How do I know when I'm in labor?
                               </span>
                               <br />
                               <br />
                               <p class="fs-5 mx-5">
                                Signs of labor can include regular contractions that befome prograssively stronger and closer together, a "bloody show"(mucus tinged with blood), rupture of the amniotic sac (water breaking), and a sesations of pressure or he baby moving down in the pelvis. If you're unsure. It's best to
                               </p>
                          </div>
                          
                          <div class="col-md-12 my-3 py-4">
                              <span class="h5 number">03</span> &nbsp;&nbsp;
                               <span class="h5">
                                How long does labor typically last?
                               </span>
                               <br />
                               <br />
                               <p class="fs-5 mx-5">
                                LLabor duration varies for each individual, In gernal, for first-time mothers. labor can last 12 to 24 hurs or longer. For women who have given birth before, labor may be shorter, typically around 6 to 12 hours. However, it's important t note that labor lenghts can vay wildly and may be influced by factors such as then woman's health. the baby's positions, and other individual.
                               </p>
                          </div>
                          
                          <div class="col-md-12 my-3 py-4">
                              <span class="h5 number">04</span> &nbsp;&nbsp;
                               <span class="h5">
                                How long does a typical labor and delivery last?
                               </span>
                               <br />
                               <br />
                               <p class="fs-5 mx-5">
                                The length of labor and delivery can vary significantly. For first-time labor can last 12 to 8 hours on average. Subsequent labors are often shorter, typiecally lasting 6 to 8 hours. However, every woman's experience is unique, and labor duration can be influenced by.
                          </div>
                          
                          <div class="col-md-12 my-3 py-4">
                              <span class="h5 number">05</span> &nbsp;&nbsp;
                               <span class="h5">
                                What are sign of labor?
                               </span>
                               <br />
                               <br />
                               <p class="fs-5 mx-5">
                               Signs of labor may include regular contractions that increase in frequencey and intensity, the rupture of the amniotic sac (water breaking), a bloody show (mucus tinged with blood), and the baby's movment shifting downwards in pelvis.
                               </p>
                          </div>
                          
                          
                          <div class="col-md-12 my-3 py-4">
                              <span class="h5 number">06</span> &nbsp;&nbsp;
                               <span class="h5">
                                Can I have a natural birth without pain medication?
                               </span>
                               <br />
                               <br />
                               <p class="fs-5 mx-5">
                                Yes, many women choose to have a natural birth without pain medication. Techniques such as breathng exercies, relaxation techniques, hydrotherapy, and movment can help manage pain during labor. It's important to duscuss your preferences with your healthcare provider and have a
                               </p>
                          </div>
                          
        				</div>
        				<div class="tab-pane mt-3" id="4a" role="tabpanel" >
                             <div class="col-md-12 my-3 py-4">
                              <span class="h5 number">01</span> &nbsp;&nbsp;
                               <span class="h5">
                               What is IVF?
                               </span>
                               <br />
                               <br />
                               <p class="fs-5 mx-5">
                               IVF, or Vitro Fertilixation, is a type of assisted reproduction technology (ART) that invoves the fertilization of an egg with sperm outside the body, in a laboratory setting. The tem "in vitro" means "in glass" referring to the laboratory dish where the fertilization take place. 
                               </p>
                          </div>
                          <div class="col-md-12 my-3 py-4">
                              <span class="h5 number">02</span> &nbsp;&nbsp;
                               <span class="h5">
                                   What medications are used during IVF?
                               </span>
                               <br />
                               <br />
                               <p class="fs-5 mx-5">
                                   During the IVF process, various medication are used to supprt the different stages of treatment. Ovarian stimulation medication, such as Folicle-Stimulating Hormone(FSH), help stumulate the ovaries to produce multiple eggs. Gonadotropin-Releasing Hormon (GnRH) agonist or antagonists are use to regulate follicle development and prevent premature ovulation. Human Chorionic Gondotropin (hCG) triggers the final maturation and release of eggs. Progesteron is administrated to support the uterin lining for embryo implantation. The specific medication and dosages are tailored to each indicidual's needs. It's important to consult with fertility specialist who will  provide personalized guidance and monitoring throughout the IVF process.  
                               </p>
                          </div>
                          
                          <div class="col-md-12 my-3 py-4">
                              <span class="h5 number">03</span> &nbsp;&nbsp;
                               <span class="h5">
                                   Who can benefit from IVF?
                               </span>
                               <br />
                               <br />
                               <p class="fs-5 mx-5">
                              IVF can help individuals or couples who have fertility issue such as blocked fallopian tubes, low sperm count, ovulation disorders, or unexplained infertility.
                               </p>
                          </div>
                          
                           <div class="col-md-12 my-3 py-4">
                              <span class="h5 number">04</span> &nbsp;&nbsp;
                               <span class="h5">
                                   How successful is IVF?
                               </span>
                               <br />
                               <br />
                               <p class="fs-5 mx-5">
                              Success rates vary depanding on several factors, including the woman's age, the quailty of eggs and sperm, the expertise of he fertility clinic and any underlying fertility issues. Sucess rates are typically higher for youger women. 
                               </p>
                          </div>
                          
                           <div class="col-md-12 my-3 py-4">
                              <span class="h5 number">05</span> &nbsp;&nbsp;
                               <span class="h5">
                                   How long does the IVF process take?
                               </span>
                               <br />
                               <br />
                               <p class="fs-5 mx-5">
                                  The entier IVF process usually takes several weeks to complete. It involves ovraian stimulation, egg retrieval, fertilization, embryo culture, embryo transfer and subsequent monitoring for pregnancy. The specific timeline may vary depending on individual circumstances and the clinic's
                          </div>
                          
                           <div class="col-md-12 my-3 py-4">
                              <span class="h5 number">06</span> &nbsp;&nbsp;
                               <span class="h5">
                                   How much does IVF cost?
                               </span>
                               <br />
                               <br />
                               <p class="fs-5 mx-5">
                                  The cost of IVF varies depending on factors such as geographic location, clinic reputation, specific treatment required, and any additional procedures or medications. It is recommeneded to inquire about the cost with the chosen fertility clinic.
                               </p>
                          </div>
                          
                		</div>
        		</div>
            </div>
            
        </div>
    </div>
</div>
<?php include_once('./layout/footer.php'); ?>