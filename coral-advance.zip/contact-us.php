<?php 
session_start();

$success_message = "";
$error_message = "";

if(!empty($_POST) && isset($_POST['contact-form'])){
   
   if( $_SESSION['captcha_code'] !== $_POST['captcha_code']) {
       $error_message = "Please enter valid captcha.";
       $success_message = "";
   } else {
        // var_dump($_SESSION); var_dump($_POST);
        $subject = $_POST['First_Name']." has submitted query from coraladvaancefertility.";
        
        $toEmail = "Info@coraladvancedfertility.com";
        
        $comment = $_POST['Comment'];
        
        
        // Always set content-type when sending HTML email
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    
        // More headers
        $headers .= 'From: Info@coraladvancedfertility.com' . "\r\n";
        //$headers .= 'Cc: myboss@example.com' . "\r\n";
        
        $html = "
            
            <html>
                <head></head>
                <body>
                    <div style='padding-left: 10px;font-size: 16px;'> 
                        <div style=''>
                            Hi Sangeetha, 
                        </div>
                        <br /> <br />
                        <div style='padding-left: 20px'> 
                            Name &nbsp;: &nbsp; ".$_POST['First_Name']." 
                        </div style='padding-left: 50px'>
                        <br /> 
                        <div style='padding-left: 20px'> 
                            Email &nbsp;: &nbsp; ".$_POST['Email']." 
                        </div>
                        <br /> 
                        <div style='padding-left: 20px'> 
                            Comment &nbsp;: &nbsp; ".$_POST['Comment']." 
                        </div>
                        
                        <br /> 
                        <div > 
                            With Regards,<br />
                            
                        </div>
                    </div>
                </body>
            </html>
        ";
        
        mail($toEmail, $subject, $html, $headers);
       $success_message = "We received your query. We will contact us soon!!";
       $error_message = "";
   }
   
   
}
?>
<?php include_once('./layout/header.php'); ?>
<div class="banner">
    <img src="/assets/images/telephone-contact-us-with-call-center-communicat-2023-01-12-05-53-27-utc.png" />
   <div class="overlay">
       <div class="overlay-content h1 text-white text-bold">
           Contact us
       </div>
   </div>
</div>

<div class="container">
    <div class="row my-5 py-5 px-5 mobile-layout">
        <div class="col-md-4">
            <div class="my-5">
                <h2 class="h1 mt-2"> Get in touch with us</h2>
                <span>We provide a complete service for the sale purchase</span>
            </div>
            <div class="my-5">
                <h4 class="mb-2">Find us at</h4>
                <hr />
                #1/1, 4th floor, above ICICI Bank,
                 NEW BEL Road, R.M.V. 2nd Stage
                 Bengaluru-560094
            </div>
            
            <div class="mb-5">
                <h4 class="mb-2"> Reach out to us at</h4>
                <!--
                <i class="fa fa-envelope"></i> &nbsp; Info@coraladvancedfertility.com 
                <br />
                <br />
                <i class="fas fa-phone-alt"></i>  &nbsp; +91 6364223969
                -->
                <img src="assets/images/contatus-contact.png" />
            </div>
            
        </div>
        <div class="col-md-8">
            <?php if(!empty($_POST) && isset($_POST['contact-form']) && strlen($success_message) > 0){ ?>
                <div class="alert alert-success" role="alert">
                   <?php echo $success_message;  ?>
                
                </div>
            <?php } else if(!empty($_POST) && isset($_POST['contact-form']) && strlen($error_message)> 0) { ?>
                <div class="alert alert-danger" role="alert">
                     <?php echo $error_message;  ?>
                
                </div>
            <?php }  ?>
            <div class="contact-us-div py-5 px-5">
                <h2> Contact Us</h2>
                 <form class="appointment-form" method="post">
                  <div class="form-row row">
                    <div class="form-group col-md-6 my-3">
                      
                      <input type="text" class="form-control" id="inputEmail4" placeholder="Enter your name" name="First_Name" required>
                    </div>
                    <div class="form-group col-md-6 my-3 ">
                      
                      <input type="email" class="form-control" id="inputPassword4" placeholder="Enter Your Email" name="Email"required >
                    </div>
                   
                    <div class="form-group col-md-12 my-3 ">
                      
                      <textarea  class="form-control"  placeholder="Your message" rows="7" name="Comment" required></textarea>
                    </div>
                    
                    <div class="form-group col-md-6 my-3 text-left">
                      
                      <img src="lib/captcha/captcha.php?rand=<?php echo $random_val;?>" id='captchaimg'>
                      <br />
                       Can't read the image? click <a href='javascript: refreshCaptcha();'>here</a> to refresh.
                    </div>
                    
                    
                    <div class="form-group col-md-6 my-3 ">
                     
                      <input type="text" class="form-control" id="inputPassword4" placeholder="Enter captcha" name="captcha_code" required >
                    </div>
                    
                    
                  </div>
                  <div class="form-group col-md-12 my-3 ">
                      
                      <input  type="checkbox" required> 
                      I agree to the pricacy policy
                    
                  </div>
                  <div class="text-center my-3">
                   <button type="submit" class="btn btn-primary btn-lg" name="contact-form">Submit</button>
                  </div>
                  
                </form>
            </div>
        </div>
    </div>
</div>
<?php include_once('./layout/book-a-meeting.php'); ?>
<?php include_once('./layout/footer.php'); ?>

