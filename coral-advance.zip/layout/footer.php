<hr style="margin: 0;padding: 0;">
<!-- !Content -->
<footer class="">
 <!--<img src="/assets/images/footer.png">-->
 <div class="">
 <div class="container py-5 ">
  <div class="row">
    <div class="col-md-12"></div>
    <div class="col-md-12">
     <h2 class="pb-4">Contact Info</h2>
     <div class="row">
      <div class="col-md-12">
       <div class="row footer-row-info">
        <div class="col-md-4 my-3">
            <img src="assets/images/footer-contact.png" />
            <!--
            <span> <i class="fa fa-mobile"></i> 
            &nbsp;  Dr. Sangeetha M J  : +91 6364223969 <br />
            &nbsp;&nbsp;&nbsp;&nbsp;  Dr. Shivananda N D : +91 9845639969 <br />
            </span>
            -->
        </div>
        <div class="col-md-4 my-3">
            <img src="assets/images/footer-email.png" />
            <!--
            <span><i class="fa fa-envelope"></i> &nbsp; Info@coraladvancedfertility.com</span>
            -->
        </div>
        <div class="col-md-4 my-3"><span><i class="fa fa-city"></i> &nbsp;
            #1/1, 4th floor, above ICICI Bank, 
            <br />
            &nbsp;&nbsp;&nbsp;&nbsp; NEW BEL Road, R.M.V. 2nd Stage
            <br />
            &nbsp;&nbsp;&nbsp;&nbsp; Bengaluru-560094
        </span></div>
       </div>
      </div>
      <!--
      <div class="col-md-12 mt-3 ">
       <div class="row footer-row-info">
        <div class="col-md-4"><span> <i class="fab fa-facebook-square"></i> &nbsp; mail@info.com</span></div>
        <div class="col-md-4"><span><i class="fab fa-instagram"></i> &nbsp; mail@info.com</span></div>
        <div class="col-md-4"><span><i class="fab fa-twitter-square"></i> &nbsp; mail@info.com</span></div>
       </div>
      </div>
      -->
     </div>
    </div>
  </div>
 </div>
</div>
</footer>

</body>
<script type='text/javascript'>
function refreshCaptcha(type="captchaimg"){
	var img = document.images[type];
	img.src = img.src.substring(0,img.src.lastIndexOf("?"))+"?rand="+Math.random()*1000;
}
</script>
</html>