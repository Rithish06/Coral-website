<?php 
    $current_page = end(explode("/", $_SERVER['REQUEST_URI']));
    $random_val   = rand();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Coral Advanced Fertility</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500&family=Roboto:wght@500;700&display=swap"
        rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/lightbox/css/lightbox.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.8.2/css/all.min.css" integrity="sha512-rqQltXRuHxtPWhktpAZxLHUVJ3Eombn3hvk9PHjV/N5DMUYnzKPC1i3ub0mEXgFzsaZNeJcoE0YHq0j/GFsdGg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
   <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
  

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>
<body>

<div class="container sticky-top" style="top: -100px;">
   <div class="container">
     <div class="row">
         <nav class="navbar navbar-expand-lg navbar-light p-lg-0">
          
             <a href="/" class="navbar-brand">
                 <img src="assets/images/logo.jpeg" />
             </a>
             <button type="button" class="navbar-toggler me-0" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
               <span class="navbar-toggler-icon"></span>
             </button>
          
        
             
           <div class="collapse navbar-collapse" id="navbarCollapse">
               <div class="navbar-nav">
                   <a href="/" class="nav-item nav-link <?php echo $current_page =='' ? 'active' :''  ?>">Home</a>
                   <a href="/doctors" class="nav-item nav-link <?php echo $current_page =='doctors' ? 'active' :''  ?>">Doctors</a>
                   <div class="nav-item dropdown">
                       <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Services</a>
                       <div class="dropdown-menu bg-light rounded-0 rounded-bottom m-0">
                           <a href="#" class="dropdown-item">
                               Bladder and Pelvic Floor Health
                           </a>
                           <a href="#" class="dropdown-item">Male Fertilty</a>
                           <a href="#" class="dropdown-item">Labor and Delivery</a>
                           <a href="#" class="dropdown-item">IVF</a>
                           <a href="#" class="dropdown-item">
                            High Risk Pregnancy Care
                           </a>
                       </div>
                   </div>
                   <a href="#" class="nav-item nav-link <?php echo $current_page =='index' ? 'gallery' :''  ?>">Gallery</a>
                   <a href="/about-us" class="nav-item nav-link <?php echo $current_page =='about-us' ? 'active' :''  ?>">About Us</a>
                   <a href="/contact-us" class="nav-item nav-link <?php echo $current_page =='contact-us' ? 'active' :''  ?>">Contact Us</a>
                   <a href="faq" class="nav-item nav-link <?php echo $current_page =='faq' ? 'active' :''  ?>">FAQ's</a>
               </div>
           </div>
         
       </nav>
    </div> 
   </div>
 </div>