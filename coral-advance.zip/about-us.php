<?php include_once('./layout/header.php'); ?>
<div class="banner">
    <img src="/assets/images/Rectangle 17331.png" />
   <div class="overlay">
       <div class="overlay-content h1 text-white text-bold">
           About Us
       </div>
   </div>
</div>

<!-- content -->
<div class="container my-5 about-us">
    <div class="row">
        <div class="col-md-6">
            <h2 class="h1 mb-5"> What we offer</h2>
            <h2> Welcome to our Advance Fertility & Maternity Care Center!</h2>
            <p class="mt-2 mb-3">
                At Advanced Fertility & Maternity Care, we undetstand that
                journey towrards paranethood can be flled with excitment, home,
                and sometimes Challenges.
                <br/>
                Out Dedicated team of medical professionals is here to provide
                you with compassion-nate care, advanced fertility treaments, and
                comprehensive maternity.
            </p>
            <h2>Our Mission</h2>
            <p class="mt-2">
                Put mission is to help individuals and couples achienve their dream of starting or expanding their families. We are comiteed to providing personalized evedince.
            </p>
        </div>
        <div class="col-md-6">
            <img src="/assets/images/Rectangle 17333.png">
        </div>
    </div>
</div>

<div class="container my-5">
    <div class="row our-services">
        <h2 class="text-center"> Our Services </h2>
        <div class="col-md-3 px-5 py-5">
            <div class="">
                <img src="/assets/images/noun-caesarean-5043089.png">
            </div>
             <h5 class="text-center mt-3">Labor and Delivery</h5>
        </div>
        <div class="col-md-3 px-5 py-5">
            <div class="">
                <img src="/assets/images/noun-bladder-2575062.png">
            </div>
            <h5 class="text-center mt-3">Bladder & Pelvic Floor Health</h5>
        </div>
        <div class="col-md-3 px-5 py-5">
            <div class="">
                <img src="/assets/images/noun-ivf-5537018.png">
            </div>
             <h5 class="text-center mt-3">IVF</h5>
        </div>
        <div class="col-md-3 px-5 py-5">
            <div class="">
                <img src="/assets/images/noun-pregnancy-1792120.png">
            </div>
             <h5 class="text-center mt-3">High-Risk Pregnency Test</h5>
        </div>
    </div>
</div>
<?php include_once('./layout/footer.php'); ?>