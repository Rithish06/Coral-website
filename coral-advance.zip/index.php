<?php include_once('./layout/header.php'); ?>
<div class="cotinaer">
  <div class="col-md-12 home-banner">
   <img src="assets/images/Capture.PNG">
  </div>
</div>
<!-- Content -->
<div class="container my-5">
  <h2 class="text-center"> Our Specialities in Maternity </h2>
 <div class="row">
  <div class="col-md-4 my-5 maternity-cards">
     <div class="" style="width: 18rem;">
       <img class="card-img-top" src="assets/images/c-section.PNG" alt="Card image cap">
       <div class="card-body">
         <h5 class="card-text text-center"> Female & male Fertility workup </h5>
       </div>
    </div>
  </div>
  <div class="col-md-4 my-5 maternity-cards">
     <div class="" style="width: 18rem;">
       <img class="card-img-top" src="assets/images/high-risk-pregnancy.PNG" alt="Card image cap">
       <div class="card-body">
        <h5 class="card-text text-center">  IUI - intrauterine insemination</h5>
       </div>
    </div>
  </div>
  <div class="col-md-4 my-5 maternity-cards">
     <div class="" style="width: 18rem;">
       <img class="card-img-top" src="assets/images/pre-post-pregnency.PNG" alt="Card image cap">
       <div class="card-body">
        <h5 class="card-text text-center">IVF, ICSI, IMSI, etc.</h5>
       </div>
    </div>
  </div>
  <div class="col-md-4 my-5 maternity-cards">
     <div class="" style="width: 18rem;">
       <img class="card-img-top" src="assets/images/pre-post-pregnency.PNG" alt="Card image cap">
       <div class="card-body">
        <h5 class="card-text text-center">Gamete & Embryo freezing</h5>
       </div>
    </div>
  </div>
  <div class="col-md-4 mb-5 maternity-cards">
     <div class="" style="width: 18rem;">
       <img class="card-img-top" src="assets/images/lectation-support.PNG" alt="Card image cap">
       <div class="card-body">
        <h5 class="card-text text-center">Fertility preservation</h5>
       </div>
    </div>
  </div>
  <div class="col-md-4 mb-5 maternity-cards">
     <div class="" style="width: 18rem;">
       <img class="card-img-top" src="assets/images/neonatal.PNG" alt="Card image cap">
       <div class="card-body">
         <h5 class="card-text text-center">Preimplantation genetic test</h5>
       </div>
    </div>
  </div>
  <div class="col-md-4 mb-5 maternity-cards">
     <div class="" style="width: 18rem;">
       <img class="card-img-top" src="assets/images/neonatal.PNG" alt="Card image cap">
       <div class="card-body">
         <h5 class="card-text text-center">Fertility enhancing surgeries- <br /> Hysteroscopy/Laparoscopy</h5>
       </div>
    </div>
  </div>
 </div> 
</div>

<div class="container  my-5 text-white">
 <div class="row ">
  <div class="col-md-12">
   <div class="row page-banner">
    <div class="col-md-3 p-0" style="background-image: url(https://coraladvancedfertility.com/assets/images/c-section.PNG);background-repeat: no-repeat;background-size: cover;"></div>
     <div class="col-md-9  py-5">
       <h2 class="text-bold "> IVF </h2>
       <p class="pb-3">
        IVF stands for In Vitro Fertilization. It is a type of assisted repductuctive technology (ART) 
        used to help individuals or couples conceive a chile when other methods have been unsuccessful.
        IVF involeves fertilizing an egg with sperm outside the body, in a laboratory settings, and then 
        transferring the resulting embryo(s) into uterus.
       </p>
       <button class="btn btn-light btn-lg"> View More...</button>
     </div>
   </div>
  </div>
 </div>
</div>

<div class="page-banner">
 <div class="container">
  <div class="row">
   <h2 class="text-white text-center my-5">Our Doctors</h2>
   <div class="row text-white">
    <div class="col-md-6 mb-5 pb-5">
     <img src="assets/images/dr-alexa.PNG">
     <h2 class="text-center m-2" > DR Alexa </h2>
      <h2 class="text-center"> (TMBBS, DGO) </h2>
    </div>
    <div class="col-md-6 mb-5 pb-5">
     <img src="assets/images/dr-alex-1.PNG">
     <h2 class="text-center m-2"> DR Alexa </h2>
      <h2 class="text-center"> (TMBBS, DGO) </h2>
    </div>
   </div>
  </div>
 </div>
</div>

<div class="my-5">
 <div class="container">
  <div class="row">
   <h2 class="theme-text text-center my-5">Why Choose Us ?</h2>
   <div class="row text-black">
    <div class="col-md-6 mt-2 p-5">
    <div class="choose-us-card">
     <i class="fas fa-stethoscope"></i>
      <h2 class="pb-2"> Greate Acuracy</h2>
      <p class="fs-3"> 
        Take care of your body. It's the only place you have to liv. 
       You dare what you eat from your head down be have to live.
      </p>
    </div>
     
    </div>
    <div class="col-md-6 mt-2 p-5">
      <div class="choose-us-card">
      <i class="fas fa-user-tie"></i>
      <h2 class="pb-2"> Trusted & Nice </h2>
      <p class="fs-3"> 
        Take care of your body. It's the only place you have to liv. 
       You dare what you eat from your head down be have to live.
      </p>
    </div>
    </div>
    <div class="col-md-6 mt-2 p-5">
      <div class="choose-us-card ">
        <i class="fas fa-user-nurse"></i>
      <h2 class="pb-2"> Specialist Nurse </h2>
      <p class="fs-3"> 
        Take care of your body. It's the only place you have to liv. 
       You dare what you eat from your head down be have to live.
      </p>
    </div>
    </div>
    <div class="col-md-6 mt-2 p-5">
      <div class="choose-us-card">
       <i class="fas fa-syringe fa-rotate-270"></i>
      <h2 class="pb-2"> Specialist Medicine </h2>
      <p class="fs-3"> 
        Take care of your body. It's the only place you have to liv. 
       You dare what you eat from your head down be have to live.
      </p>
    </div>
    </div>
   </div>
  </div>
 </div>
</div>

<?php include_once('./layout/book-a-meeting.php'); ?>
<?php include_once('./layout/footer.php'); ?>