<?php include_once('/home/sangeetha1/public_html/layout/header.php'); ?>

<div class="banner">
    <img src="/assets/images/Rectangle 17331.png" />
   <div class="overlay">
       <div class="overlay-content h1 text-white text-bold">
           Gamete & Embryo freezing
       </div>
   </div>
</div>
<div class="container">
    <div class="row box px-5 py-5 my-5">
        <h1 class="h1-color">
            What is Gamete & Embryo freezing?
        </h1>
        <p class="text-format">
          Embryo freezing is a procedure that allows people to store embryos for
          future use. A person can also freeze eggs, which are not fertilized.
          An embryo forms after fertilization and after the cells start to 
          divide.
          <br />
          The first successful pregnancy resulting from freezing a healthy
          embryo took place in 1980. The term Embryo means from the moment that
          cells divide after fertilization until the eight weeks of pregnancy.
          <br />
          Before freezing can take place, First, patients need to create 
          suitable embryos. First, the person will take hormone injections to
          produce more eggs. These eggs are retrieved under Transvaginal
          ultrasound guidance. A person may wish to freeze their eggs if she
          wants.
          <br />
          The eggs were fertilized by sperm IVF or ICSI technique, in the
          laboratory. After fertilization, embryos are kept in special culture
          media for 2 to 6 days in the incubator. Once the embryos reaches the
          blastocyst stage, the embryo transfer will be done. The surplus
          embryos are frozen for future use.
          <br />
          While freezing the biggest challenge is the water within the cells.
          When this water freezes, water crystals can form and burst the cell.
          This is the reason for the poor success rate in frozen embryo transfer.
          <br />
          Now, slow freezing is completely replaced by the vitrification method.
        </p>
    </div>
    
    <div class="row box px-5 py-5 my-5">
       <h2 class="h1 h1-color">Vitrification</h2>
        <p class="text-format">
          In this process, the embryologist vitrifies the cryoprotected Embryos
          so quickly that the water, molecules do not have time to form, Ice
          crystals. This helps to protect the embryos and ovum, increases their
          rate of survival during thawing. After freezing is complete, embryo’s
          are stored in liquid nitrogen.
        </p>
    </div>
    
    <div class="row box px-5 py-5 my-5">
       <h2 class="h1 h1-color">Success Rate Of Thawing Frozen Embryo</h2>
        <p class="text-format">
         The process of thawing a vitrified embryo after cryopreservation has a
         relatively high success rate and good chances of delivering healthy
         babies, no increase in development anomalies. Research showed that
         vitrification increases an embryo’s chances of survival, comparable
         with fresh transfer.
        </p>
    </div>

    <div class="row box px-5 py-5 my-5">
       <h2 class="h1 h1-color">How Long Can Embryos And Gametes Stay Frozen?</h2>
        <p class="text-format">
        In theory, frozen embryos or gametes can remain viable for any length
        of time.
        The embryo’s remain in sealed containers at a temperature of -321’F. At
        this temperature, no biological process such as aging can occur.
        The length of time that a person and the fees can store their embryos
        will be discussed in person.
        </p>
    </div>
</div>

<?php include_once('/home/sangeetha1/public_html/layout/footer.php'); ?>