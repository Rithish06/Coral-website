<?php include_once('/home/sangeetha1/public_html/layout/header.php'); ?>

<div class="banner">
    <img src="/assets/images/Rectangle 17331.png" />
   <div class="overlay">
       <div class="overlay-content h1 text-white text-bold">
           Fertility Preservation
       </div>
   </div>
</div>
<div class="container ">
    
    
    <div class="row my-5">
        <h1 class="h1-color">
            PREIMPLANTATION GENETIC TESTING
        </h1>
        <p class="text-format">
           Fertility preservation is the term used for interventions and
           procedures aiming at preserving the chance of having a baby when the
           fertility may be damaged by certain medical conditions or treatment
           for the same.
        </p>
    </div>
    
    <div class="row box px-5 py-5 my-5">
        <h1 class="h1-color">
            When is it advised
        </h1>
        <ul class="text-format">
          <li>
              In men, women or couple with cancer, who are undergoing treatment
              such as chemotherapy, radiotherapy or even surgery for the same.
              These treatments may be toxic for the eggs/sperms or may decrease
              the ovarian reserve in women or the sperm counts in men. So
              Fertility preservation is done in such conditions.
          </li>
          <li>
              Fertility preservation may be done in women/couple’s who want to
              postpone their pregnancy.
          </li>
        </ul>
        
        <h2 class="h1-color mt-4">
            What are the options for Fertility Preservation at Kangaroo Care Fertility
        </h2>
        <ul class="text-format">
           <li>
             We provide fertility preservation in the form of freezing eggs
             /embryos in women with serious illnesses such as cancer that will
             potentially risk damage to your eggs from chemotherapy,
             radiotherapy or other treatments, including surgery.
          </li>
          <li>
             We provide option for freezing eggs in women who are not ready to
             have a baby right now.
          </li>
          <li>
             We freeze sperms of men who have cancer or undergoing any treatment
             which is going to be lethal to the sperms.
          </li>
        </ul>
        
    </div>
    
     
    
    
</div>

<?php include_once('/home/sangeetha1/public_html/layout/footer.php'); ?>