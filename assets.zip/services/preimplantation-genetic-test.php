<?php include_once('/home/sangeetha1/public_html/layout/header.php'); ?>

<div class="banner">
    <img src="/assets/images/Rectangle 17331.png" />
   <div class="overlay">
       <div class="overlay-content h1 text-white text-bold">
           Preimplantation Genetic Test
       </div>
   </div>
</div>
<div class="container ">
    
    
    <div class="row my-5">
        <h1 class="h5 text-format">
            Preimplantation genetic testing (PGT) is a pair of twin procedures that check for genetic defects in embryos created through in vitro fertilisation (IVF) technology. The PGT umbrella is composed of preimplantation genetic screening (PGS) and preimplantation genetic diagnosis(PGD)
        </h1>
    </div>
    
    <div class="row box px-5 py-5 my-5">
        <h1 class="h1-color">
            PREIMPLANTATION GENETIC TESTING
        </h1>
        <p class="text-format">
           PGS is a method that screens embryos of chromosomally normal genetic parents, for structural or numerical chromosomal anomalies.
        </p>
        
        <h2 class="h1-color mt-4">
            PREIMPLANTATION GENETIC DIAGNOSIS
        </h2>
        <p class="text-format">
           PGD is performed to trace potential embryonic defects in couples where one or both partners have a known genetic abnormality. The procedure is capable of detecting sex-linked disorders, single gene defects and chromosomal disorders.
        </p>
        
    </div>
    
     <div class="row box px-5 py-5 my-5">
        <span class="h1 h1-color">
            ADVANTAGES OF PREIMPLANTATION GENETIC TESTING TECHNOLOGY
        </span>
        
        <h2 class="h1 h1-color">ELIMINATION OF GENETIC PREDISPOSITION</h2>
        <p class="text-format">
           PGT works like a sieve, eliminating embryos that carry unfavourable chromosomal properties. It is especially useful for couples who want to prevent existing genetic conditions from being passed on.
        </p>
        
        <h2 class="h1-color mt-4">
            PRACTICAL DECISION MAKING
        </h2>
        <p class="text-format">
           Genetic testing is commonly favoured over conventional post-conception diagnostic procedures which often entail difficult decision making surrounding potential pregnancy termination.
        </p>
        
    </div>
    
    
</div>

<?php include_once('/home/sangeetha1/public_html/layout/footer.php'); ?>