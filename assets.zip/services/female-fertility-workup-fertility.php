<?php include_once('/home/sangeetha1/public_html/layout/header.php'); ?>

<div class="banner">
    <img src="/assets/images/Rectangle 17331.png" />
   <div class="overlay">
       <div class="overlay-content h1 text-white text-bold">
           Female Fertility Workup
       </div>
   </div>
</div>

<div class="container ">
    <div class="row my-5">
        <h1 class="h1-color">Fertility In Female</h1>
        <p class="text-format">
            Infertility means not being able to get pregnant after at least 
            one year of trying (or 6 months if the woman is over age 35). 
            If a woman keeps having miscarriages, it is also called infertility.
            Female infertility can result from age, physical problems, hormone
            problems, and lifestyle or environmental factors.
            <br />
            As age progresses, fertility decreases. Especially in women,
            fertility decreases at an alarming rate after 35yrs of age.
        </p>
    </div>
    
    <div class="row my-5">
        <h2 class="h1-color">Causes of Male Infertility</h2>
        <p class="text-format my-2">
           Conceiving a healthy baby depends on a number of factors, including
           healthy sperm. In fact, male infertility is the second biggest issue
           after a woman’s age so it’s important to understand how the male
           reproductive system works. The most common causes of male infertility
           are called:
        </p>
        <div class="pl-3">
            <ul class="text-format">
                <li>Hormonal Blood Tests- They are done at varying times of the menstrual cycle. They are- Serum FSH, LH, E2, AMH, TSH, Prolactin.</li>
                <li>Oligospermia, where few sperm cells are produced.</li>
                <li>Hysterosalpingography (HSG)- A procedure done to know the patency of the tubes. It can be done with or without anaesthesia.</li>
                <li>Ultrasound (2D/3D)- done to evaluate the uterus, tubes and ovaries. Usually a transvaginal USG is done as it has a better resolution.</li>
                <li>Hysteroscopy/Laparoscopy- These are the minimally invasive procedures, done under anaesthesia, to evaluate the pelvic organs. We can obtain a live image of the organs and make a definite diagnosis.</li>
            </ul>
        </div>
    </div>
    
    <div class="row my-5">
        <h2 class="h1-color">Female Fertility Treatment</h2>
        <p class="text-format my-2">
           Fertility treatment aims to help the women to bear child naturally or
           through assisted reproduction. The various options available for the
           woman at Kangaroo Care Fertility are-
        </p>
        <div class="pl-3">
            <ul class="text-format">
                <li>Ovulation Induction</li>
                <li> Intrauterine Insemination (IUI)</li>
                <li>In-vitro Fertilization (IVF)</li>
                <li>Intracytoplasmic Sperm Injection (ICSI)</li>
                <li>Laparoscopy & Hysteroscopy</li>
            </ul>
        </div>
    </div>
    
    
</div>

<?php include_once('/home/sangeetha1/public_html/layout/footer.php'); ?>