<?php include_once('/home/sangeetha1/public_html/layout/header.php'); ?>
<div class="banner">
    <img src="/assets/images/Rectangle 17331.png" />
   <div class="overlay">
       <div class="overlay-content h1 text-white text-bold">
           Male Fertility Workup
       </div>
   </div>
</div>

<div class="container my-5">
    <div class="row my-5">
        <h1 class="h1-color">Fertility In Men</h1>
        
        <div class="col-md-8 mt-3">
            <p>
                Male infertility isn't spotlighted nearly as much as it should be. The truth is, the male partner plays as much of a role in a couple's ability to conceive as the female partner. Male infertility could be caused by several factors, including erectile dysfunction, age-related subfertility and low sperm motility. However, with the right medical intervention, male infertility can be effectively managed and treated. On Cloudnine, our expertly designed treatment protocols can help you and your partner expand your family in the best way possible.
    
                    A treatment programme on Cloudnine is normally divided into
                    three key stages but may differ based on your background, health
                    and medical history.
            </p>
        </div> 
        
        <div class="col-md-4 text-cemter mt-3">
            <img src="/assets/images/services/2021flat_187.jpg" style="width: 350px;" />
        </div>
    </div>
    <div class="row my-5">
        <h2 class="h1-color">Causes of Male Infertility</h2>
        <h6 class="text-format">Conceiving a healthy baby depends on a number of factors, including healthy sperm. In fact, male infertility is the second biggest issue after a woman’s age so it’s important to understand how the male reproductive system works. The most common causes of male infertility are called:
        </h6>
        <div class="pl-3">
            <ul class="text-format">
                <li>Azoospermia, no sperm cells are produced.</li>
                <li>Oligospermia, where few sperm cells are produced.</li>
                <li>Teratospermia, where a high proportion of sperm is abnormally shaped.</li>
                <li>Blocked or absent vas deferens</li>
                <li>Vas deferens is the tube that transports the sperm from the testes</li>
                <li>Genetic condition such as cystic fibrosis or chromosomal abnormality.</li>
                <li>High sperm DNA fragmentation that can affect a sperm's ability to fertilise an egg.</li>
                <li>Sperm antibodies that can interfere with sperm motility and fertilisation.</li>
            </ul>
        </div>
        <div class="my-2">
            <h2 class="h1-color">Consultation</h2>
            <p class="text-format">
                Every treatment programme  is thoughtfully designed keeping you and your partner in mind, with your combined medical history, financial inclination and long-term goals forming the fulcrum for a personalised treatment plan. In line with this, your treatment programme will open with you and your partner being invited in for a consultation with a fertility specialist. In this consultation, your specialist will review your medical details, spotlight areas of concern and recommend potential paths to fertility.
            </p>
        </div>
        
        <div class="my-2">
            <h2 class="h1-color">Initial Fertility Screening</h2>
            <h6 class="text-format">
                Your consultation will be followed by a detailed fertility screening composed of tests that will be tailored to your medical profile. A guest typically undergoes the following screening tests, although these may vary from case to case:
            </h6>
            <div class="pl-3">
                <ul class="text-format">
                    <li>Basic Tests</li>
                    <li>Basic blood work up</li>
                    <li>Semen analysis</li>
                    <li>Hormonal assay</li>
                    <li>Hysterosalpingogram (HSG) for tubal evaluation</li>
                    <li>Diagnostic hystero laparoscopy (if HSG results are abnormal)</li>
                    <li>Special Tests, In Select Cases</li>
                    <li>Sperm DFI</li>
                    <li>3D scan</li>
                    <li>Detailed evaluation of male partner (scan, hormonal assay, chromosomal analysis)</li>
                     <li>Gene X-pert plus</li>
                </ul>
            </div>
        </div>
        
        <div class="my-2">
            <h2 class="h1-color">Treatment Recommendation & Implementation</h2>
            <span class="h6 text-format">
                Your treatment plan may comprise a single fertility procedure or a combination of fertility routines. Some of these are mentioned below:
            </span>
            <div class="pl-3">
                <ul class="text-format">
                    <li>Ovulation induction and cycle monitoring</li>
                    <li>Intrauterine insemination (IUI)</li>
                    <li>In vitro fertilisation (IVF)</li>
                    <li>Intracytoplasmic sperm injection (ICSI)</li>
                    <li>Physiological intracytoplasmic sperm injection (PICSI)</li>
                    <li>Micro testicular sperm extraction (micro TESE)</li>
                    <li>Preimplantation genetic screening (PGS)/Preimplantation genetic diagnosis (PGD)</li>
                    <li>Time lapse embryo monitoring</li>
                    <li>Endometrial receptivity test (ERA)</li>
                    <li>Laser assisted hatching (LAH)</li>
                    <li>Frozen embryo transfer (FET)</li>
                    <li>Third-party reproduction, including surrogacy</li>
                </ul>
            </div>
        </div>
        
    </div>
</div>
<?php include_once('/home/sangeetha1/public_html/layout/footer.php'); ?>