<?php include_once('./layout/header.php'); ?>

<?php
$folder = './assets/images/gallery/';
$images = glob($folder . '*.{jpg,jpeg,png,gif}', GLOB_BRACE);
//var_dump($images);
?>
<div class="banner">
    <img src="/assets/images/Rectangle 17331.png" />
   <div class="overlay">
       <div class="overlay-content h1 text-white text-bold">
           Gallary
       </div>
   </div>
</div>
<div class="container my-5">
   
    
    <div class="row">
        <?php foreach($images as $image) { ?>
         <div class="col-md-4 py-2">
             <a href="<?php echo $image ?>?image=251" data-toggle="lightbox" data-gallery="example-gallery" class="col-sm-4 py-2 text-center" >
    		<img src="<?php echo $image ?>?image=251" class="img-fluid">
	    </a>
         </div>
           
        <?php } ?>
	<!--
	<a href="assets/images/gallery/524061b8f5e9011ab0efae444be53570.jpg?image=252" data-toggle="lightbox" data-gallery="example-gallery" class="col-sm-4 py-2">
		<img src="assets/images/gallery/524061b8f5e9011ab0efae444be53570.jpg?image=252" class="img-fluid">
	</a>
	<a href="assets/images/gallery/b476962fa89ca403b140999166b18961.png?image=253" data-toggle="lightbox" data-gallery="example-gallery" class="col-sm-4 py-2">
		<img src="assets/images/gallery/b476962fa89ca403b140999166b18961.png?image=253" class="img-fluid">
	</a>
	<a href="assets/images/gallery/b2b51036da3fa14eabd5aeac83d5765c.png?image=253" data-toggle="lightbox" data-gallery="example-gallery" class="col-sm-4 py-2">
		<img src="assets/images/gallery/b2b51036da3fa14eabd5aeac83d5765c.png?image=253" class="img-fluid">
	</a>
	-->
</div>
</div>
<script>

  
</script>
<?php include_once('./layout/footer.php'); ?>
